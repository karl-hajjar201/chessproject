(* Note: You may introduce new code anywhere in this file. *) 
open Piece
open Command

exception Invalid_Move
(* TODO: replace [unit] with a type of your own design. *)
type t = {
  current_team : Piece.team;
  active_pieces: Piece.piece list; 
  (* ^^ is a list of the active pieces in the game *)
}

let init_pieces: Piece.piece list =
  let wp1 = [set_piece ('a', 2) Pawn White true] in
  let wp2 = [set_piece ('b', 2) Pawn White true] in
  let wp3 = [set_piece ('c', 2) Pawn White true] in
  let wp4 = [set_piece ('d', 2) Pawn White true ]in
  let wp5 = [set_piece ('e', 2) Pawn White true] in
  let wp6 = [set_piece ('f', 2) Pawn White true] in
  let wp7 = [set_piece ('g', 2) Pawn White true ]in
  let wp8 = [set_piece ('h', 2) Pawn White true] in

  let wr1 = [set_piece  ('a', 1) Rook White true] in
  let wk1 = [set_piece ('b', 1) Knight White true] in
  let wb1 = [set_piece ('c', 1) Bishop White true] in
  let wk = [set_piece  ('d', 1)  King White true] in
  let wq = [set_piece ('e', 1) Queen White true] in
  let wb2 = [set_piece ('f', 1)  Bishop White true] in
  let wk2 = [set_piece ('g', 1)  Knight White true ]in
  let wr2 = [set_piece ('h', 1)  Rook White true] in


  let bp1 = [set_piece ('a', 7)  Pawn Black true] in
  let bp2 = [set_piece ( 'b', 7)  Pawn Black true] in
  let bp3 = [set_piece ('c', 7)  Pawn Black true] in
  let bp4 = [set_piece ('d', 7) Pawn Black true] in
  let bp5 = [set_piece ('e', 7) Pawn Black true] in
  let bp6 = [set_piece ('f', 7) Pawn Black true] in
  let bp7 = [set_piece ('g', 7) Pawn Black true] in
  let bp8 = [set_piece ('h', 7) Pawn Black true] in

  let br1 = [set_piece ('a', 8) Rook Black true ]in
  let bk1 = [set_piece ('b', 8) Knight Black true] in
  let bb1 = [set_piece ('c', 8) Bishop Black true ]in
  let bk = [set_piece ('d', 8) King Black true ]in
  let bq = [set_piece ('e', 8) Queen Black true] in
  let bb2 = [set_piece ('f', 8) Bishop Black true] in
  let bk2 = [set_piece ('g', 8) Knight Black true] in
  let br2 = [set_piece ('h', 8) Rook Black true] in
  let final = [wp1;wp2;wp3;wp4;wp5;wp6;wp7;wp8;wr1;wk1;wb1;wk;wq;wb2;wk2;wr2;bp1;bp2;bp3;bp4;bp5;bp6;bp7;
               bp8;br1;bk1;bb1;bk;bq;bb2;bk2;br2;] in
  List.flatten final

let init_state ={
  current_team = White;
  active_pieces = init_pieces;
}

let win_condition_black st = 
  failwith("unimplimented")

let win_condition_white st = 
  failwith("unimplimented")

let move com st = 
  failwith("unimplimented")

let win_condition st adv = 
  failwith("unimplimented")

let contents t loc : Piece.piece option = 
  let x = List.filter (fun r -> Piece.get_location r = loc) t.active_pieces in
  match x with
  | h::[] -> Some h
  | [] -> None
  | h::t -> failwith "Error"

let moving_up (location: Piece.location) (destination: Piece.location) : bool =
  let loc_row = row_from_location location in 
  let des_row = row_from_location destination in
  if des_row > loc_row then true else false

let rec clear_vert_check t (location: Piece.location) (destination: Piece.location) : bool =
  if row_from_location location = row_from_location destination - 1 then true
  else if contents t (column_from_location location,row_from_location location + 1) = None then false
  else clear_vert_check t (column_from_location location, row_from_location location+1) destination

let clear_vertically t (moveset: Command.move_set) : bool = 
  let location = first_from_moveset moveset in 
  let destination = second_from_moveset moveset in
  match moving_up location destination with
  |true -> clear_vert_check t location destination 
  |false -> clear_vert_check t destination location
(*^^Handles every space in between, NOT COUNTING DESTINATION. Should work for moving 
  up or down*)
let moving_right (location: Piece.location) (destination: Piece.location) : bool =
  let loc_col = Char.code(column_from_location location) -64 in 
  let des_col = Char.code(column_from_location location) -64 in
  if loc_col < des_col then true else false

let column_stepper (location: Piece.location) : char = 
  Char.chr(Char.code(column_from_location location) -63)

let rec clear_horiz_check t (location:Piece.location) (destination: Piece.location) : bool =
  if Char.code(column_from_location location) -64 = Char.code(column_from_location destination) -1
  then true else if contents t (Char.chr(Char.code(column_from_location location) -63),row_from_location location) = None then false
  else clear_horiz_check t (column_stepper location,row_from_location location) (column_from_location destination,row_from_location destination)

let clear_horizontally t (moveset: Command.move_set) : bool =
  let location = first_from_moveset moveset in 
  let destination = second_from_moveset moveset in
  match moving_right location destination with
  |true -> clear_horiz_check t location destination
  |false -> clear_horiz_check t destination location

let plane_of_movement (moveset:Command.move_set) : string =
  let location = first_from_moveset moveset in 
  let destination = second_from_moveset moveset in
  if Piece.column_from_location location = Piece.column_from_location destination then "vertical" else if
    Piece.row_from_location location = Piece.row_from_location destination then "horizontal" else
    "diagonal"

let rec clear_diag_check t location destination (vert_step:int) (horiz_step: int) : bool =
  if Char.code(column_from_location location) -64 = Char.code(column_from_location destination) + horiz_step && 
     row_from_location location = row_from_location destination + vert_step then true else if contents t (Char.chr(Char.code(column_from_location location) - 64 + horiz_step),row_from_location location + vert_step) = None
  then false else clear_diag_check t (Char.chr(Char.code(column_from_location location) - 64 + horiz_step),row_from_location location + vert_step) destination vert_step horiz_step

let clear_diagonally t (moveset: Command.move_set) : bool = 
  let location = first_from_moveset moveset in 
  let destination = second_from_moveset moveset in
  match moving_right location destination with
  |true -> (let horiz_step = 1 in
            match moving_up location destination with
            |true -> let vert_step = 1 in clear_diag_check t location destination vert_step horiz_step
            |false -> let vert_step = -1 in clear_diag_check t location destination vert_step horiz_step
           )
  |false ->( let horiz_step = -1 in
             match moving_up location destination with
             |true -> let vert_step = 1 in clear_diag_check t location destination vert_step horiz_step
             |false -> let vert_step = -1 in clear_diag_check t location destination vert_step horiz_step 
           )

let get_current_team t = 
  match t.current_team with 
  | White -> "White team, "
  | Black -> "Black team, "

let rec next_turn old_peice new_peice piece_list = 
  match piece_list with 
  | h :: t -> if Piece.equal old_peice h then new_peice :: t else h :: next_turn old_peice new_peice t
  | [] -> failwith "Didn't work"

let move t rank start finish =
  match contents t start with 
  | Some x -> begin 
      match (get_team x = t.current_team) && (get_rank x = rank) with
      | true -> next_turn x (set_piece finish rank t.current_team false) t.active_pieces
      | false -> raise Invalid_Move
    end
  | None -> raise Invalid_Move

let go command t : t =
  let new_team = match t.current_team with 
    | White -> Black
    | Black -> White in
  let new_piece_list = match command with
    | Pawn (s, f) -> move t Pawn s f
    | Knight (s, f) -> move t Knight s f
    | Rook (s, f) -> move t Rook s f
    | King (s, f) ->  move t King s f
    | Queen (s, f) -> move t Queen s f
    | Bishop (s, f) -> move t Bishop s f
    | Forfit -> [] in
  {current_team = new_team; active_pieces = new_piece_list}

(** Take in a command, Rank and (location, location)
    check if there is actually the right piece at the first move set
    check that the piece type can move to the second move set*)

(* if it's good, change the piece's location, give back a new state with the changes reflected in the piece list *)
