(* TODO: set the value below *)
<<<<<<< HEAD
let hours_worked = 24
=======
let hours_worked = 10
>>>>>>> 8009092c1941a8292f7a39e52c59de33b9fb3c53
